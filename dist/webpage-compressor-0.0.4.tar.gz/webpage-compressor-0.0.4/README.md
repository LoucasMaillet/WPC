# What is this ?

Web Page Compressor (v0.2) is a Python command line utils to create one page website.

# What wasn't finish:

WPC didn't support "//" comments.

# Table of Contents

* [Help](#help)
* [Reports](#reports)

# Help

```sh
usage:
wpc [-h] [-n webpage] [-b [mode]] [filePath]

positional arguments:
  filePath              Path of main file.

optional arguments:
  -h, --help            show this help message and exit
  -n webpage, --new webpage
                        Generate new WPC environment..
  -b [mode], --build [mode]
                        Build webpage.
```

# Report

Well the code wasn't rigth writed... So I will see later.